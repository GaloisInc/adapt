#!/usr/bin/env Rscript
devtools::test()